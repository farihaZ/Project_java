module com.institutmvm.controller {
    requires cat.institutmvm.applicacio;
    requires java.desktop;
}