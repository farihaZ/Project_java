package com.institutmvm.controller.ui;
import cat.institutmvm.applicacio.entities.Especies;
import cat.institutmvm.applicacio.ui.Formulario;
//import cat.institutmvm.applicacio.utils.Validation;
import java.util.Scanner;

public class Main {
        public static void main(String[] args) {
                Formulario formulario = new Formulario();
                formulario.setVisible(true);
        }


}







