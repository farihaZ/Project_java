module cat.institutmvm.applicacio {
    requires java.desktop;
    exports cat.institutmvm.applicacio.entities;
    //exports cat.institutmvm.applicacio.utils;
    exports cat.institutmvm.applicacio.ui;
}